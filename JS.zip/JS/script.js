const users = [
    { id: "Kasilda", balance: 1000 },
    { id: "Kristi", balance: 2500 }
];

let currentUser = null;

function checkUser() {
    const userId = document.getElementById('userId').value;
    const message = document.getElementById('message');
    const atmOptions = document.getElementById('atm-options');
    const balanceDisplay = document.getElementById('balance');

    currentUser = users.find(user => user.id === userId);

    if (currentUser) {
        message.textContent = "Login successful!";
        atmOptions.style.display = 'block';
        balanceDisplay.textContent = currentUser.balance;
    } else {
        message.textContent = "User not found. Try again.";
        atmOptions.style.display = 'none';
    }
}

function withdraw() {
    const amount = parseFloat(document.getElementById('withdrawAmount').value);
    const message = document.getElementById('message');
    const balanceDisplay = document.getElementById('balance');

    if (currentUser) {
        if (amount > currentUser.balance) {
            message.textContent = "Insufficient funds.";
        } else {
            currentUser.balance -= amount;
            balanceDisplay.textContent = currentUser.balance;
            message.textContent = `Withdrawal successful! You withdrew $${amount}.`;
        }
    } else {
        message.textContent = "Please log in first.";
    }
}
